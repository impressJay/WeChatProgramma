import Sprite   from '../base/sprite'
import DataBus  from '../databus'

const BULLET_IMG_SRC = 'images/bluepoint.png'

const screenWidth = window.innerWidth
const screenHeight = window.innerHeight

var scale = 3
var width = screenWidth - (screenWidth / scale) * 2;
var height = screenWidth - (screenWidth / scale) * 2;

const BULLET_WIDTH = width/3 -2
const BULLET_HEIGHT = width/3 -2
var  state =1;

const __ = {
  speed: Symbol('speed')
}

let databus = new DataBus()
export default class Bullet extends Sprite {
  constructor() {
    super(BULLET_IMG_SRC, BULLET_WIDTH, BULLET_HEIGHT)

  }
  init(x, y, speed) { 
    this.x =x
    this.y =y
    this[__.speed] =speed
    this.visible = true
  }


  update(destroy_flag) {     
    if (destroy_flag == 1 )  //前一个蓝色球被销毁后，更新另一个蓝色球
    {
      databus.removeBullets(this)
      return 1;
    }
  }
}
