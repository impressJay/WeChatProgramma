import Sprite   from '../base/sprite'
import Bullet   from './bullet'
import DataBus  from '../databus'

const screenWidth    = window.innerWidth
const screenHeight   = window.innerHeight

var scale = 3
var width = screenWidth - (screenWidth / scale) * 2;
var height = screenWidth - (screenWidth / scale) * 2;

var left_top_x = screenWidth /scale
var left_top_y = screenHeight /scale
// 玩家相关常量设置
const PLAYER_IMG_SRC = 'images/User.png'
const PLAYER_WIDTH   = width/3 -2
const PLAYER_HEIGHT  = width/3 -2

let databus = new DataBus()

export default class Player extends Sprite {
  constructor() {
    super(PLAYER_IMG_SRC, PLAYER_WIDTH, PLAYER_HEIGHT)
    // 红球默认处于屏幕底部居中位置
    this.x = screenWidth/3 + width/2 -20 -2  
    this.y = screenHeight/3 + width/2 -20 -2
    this.bullets = []
    // 初始化事件监听
    this.initEvent()
  }

  /**
   * 当手指触摸屏幕的时候
   * 判断手指是否在飞机上
   * @param {Number} x: 手指的X轴坐标
   * @param {Number} y: 手指的Y轴坐标
   * @return {Boolean}: 用于标识手指是否在红球上的布尔值
   */
  checkIsFingerOnAir(x, y) {
    const deviation = 30
    return !!(   x >= this.x - deviation
              && y >= this.y - deviation
              && x <= this.x + this.width + deviation
              && y <= this.y + this.height + deviation  )
  }

  /**
   * 玩家响应手指的触摸事件
   * 改变红球的位置
   */
  initEvent() {
    canvas.addEventListener('touchstart', ((e) => {
      e.preventDefault()

      let x = e.touches[0].clientX 
      let y = e.touches[0].clientY 
      
      if(x - this.x >= width*2/3|| y - this.y >= width*2/3|| this.x -x >= width*2/3 || this.y - y>=width*2/3)
      {
            return;
      }
    if ((x >= left_top_x && x <= left_top_x + width) && (y >= left_top_y) && (y <= left_top_y + width))
    {
      //******************  第一行         *************************************
      if ((x >= left_top_x) && (x < left_top_x + width/3) && (y >= left_top_y) && (y <= left_top_y+ width/3))
       {
           this.x = left_top_x 
           this.y = left_top_y 
       }
       else  if ((x >= left_top_x) && (x < left_top_x + width*2/3) && (y >= left_top_y) && (y <= left_top_y+ width/3))
       {
        this.x = left_top_x + width/3
        this.y = left_top_y
       }
      else if ((x >= left_top_x) && (x < left_top_x + width) && (y>=left_top_y) && (y <= left_top_y + width / 3))
      {
        this.x = left_top_x + width*2/3
        this.y = left_top_y
      }

       //**************    第二行             *****************************************
      else if((x >= left_top_x) && (x < left_top_x + width/3) && (y >= left_top_y + width/3) && (y <= left_top_y + width*2/3))
       {
           this.x = left_top_x 
           this.y = left_top_y + width/3
       }
      else if ((x >= left_top_x+width/3) && (x < left_top_x + width*2/3) && (y >= left_top_y + width/3) && (y <= left_top_y + width*2/3)){
        this.x = left_top_x + width/3
        this.y = left_top_y + width/3
      }
      else if ((x >= left_top_x+width*2/3) && (x < left_top_x + width) && (y >= left_top_y + width/ 3) && (y <= left_top_y + width*2/3)) 
      {
        this.x = left_top_x + width*2/3
        this.y = left_top_y + width/3
      }
       //**************    第三行             *****************************************
      else if ((x >= left_top_x) && (x < left_top_x + width / 3) && (y >= left_top_y + width*2/ 3) && (y <= left_top_y + width)) {
        this.x = left_top_x
        this.y = left_top_y + width*2/ 3
      }
      else if ((x >= left_top_x + width / 3) && (x < left_top_x + width * 2 / 3) && (y >= left_top_y + width*2/ 3) && (y <= left_top_y + width)) {
        this.x = left_top_x + width / 3
        this.y = left_top_y + width*2/ 3
      }
      else if ((x >= left_top_x + width * 2 / 3) && (x < left_top_x + width) && (y >= left_top_y + width*2/ 3) && (y <= left_top_y + width)) {
        this.x = left_top_x + width * 2 / 3
        this.y = left_top_y + width*2/ 3
      }
        this.touched = true
    }
}).bind(this))
  }

  /**
    蓝色球的位置
   */
  BlueBallGenerate(x,y,destroy_flag) {
    if (destroy_flag == 2)
    {   
        var blueBall_x=left_top_x
        var blueBall_y=left_top_y
        var state = Math.floor(Math.random() * 10)
        switch(state)
        {
        
            case 1:
           blueBall_x = left_top_x 
           blueBall_y = left_top_y          
                    break;
            case 2: 
            blueBall_x = left_top_x + width/3
            blueBall_y = left_top_y           
                    break;
            case 3: 
            blueBall_x = left_top_x + width*2/3
            blueBall_y = left_top_y      
                    break;

            case 4:
            blueBall_x = left_top_x
            blueBall_y = left_top_y + width/3 
                    break;
            case 5:
            blueBall_x = left_top_x + width/3
            blueBall_y = left_top_y + width/3 
                    break;
            case 6:
            blueBall_x = left_top_x + width*2/3
            blueBall_y = left_top_y + width/3 
                    break;
            case 7:
            blueBall_x = left_top_x
            blueBall_y = left_top_y + width*2/ 3 
                    break;
            case 8:
            blueBall_x = left_top_x + width/3
            blueBall_y = left_top_y + width*2/3 
                    break;
            case 9:
            blueBall_x = left_top_x + width*2/3
            blueBall_y = left_top_y + width*2/3 
                    break;
            default:           
                  break;     
        }
    let bullet = databus.pool.getItemByClass('bullet', Bullet)
    bullet.init(
      blueBall_x, 
      blueBall_y, 
      1
    )
    databus.bullets.push(bullet)
  }
 }
}
