import Animation from '../base/animation'
import DataBus from '../databus'

const ENEMY_IMG_SRC = 'images/HeiZi.png'

const screenWidth = window.innerWidth
const screenHeight = window.innerHeight

var scale = 3
var width = screenWidth - (screenWidth / scale) * 2;
var height = screenWidth - (screenWidth / scale) * 2;

const ENEMY_WIDTH = width/3
const ENEMY_HEIGHT = width/3

var enemyGenerate_Flag = 0;
var enemy_x = 0;

const __ = {
  speed: Symbol('speed')
}
let databus = new DataBus()
function rnd(start, end) {
  return Math.floor(Math.random() * (end - start) + start)
}

export default class Enemy extends Animation {
  constructor() {
    super(ENEMY_IMG_SRC, ENEMY_WIDTH, ENEMY_HEIGHT)
  }


  init(speed) {
    enemy_x = Math.floor(Math.random() * 10)
    if (enemy_x <= 3) {
      enemy_x = 1;
    }
    else if (enemy_x > 3 && enemy_x <= 6) {
      enemy_x = 2;
    }
    else if (enemy_x > 6 && enemy_x <= 9) {
      enemy_x = 3;
    }
    switch (enemy_x) {
      case 1: this.x = 0
        this.y = screenHeight/scale 
        break;
      case 2: this.x = 0
        this.y = screenHeight/scale + width/3
        break;
      case 3: this.x = 0
        this.y = screenHeight / scale + width*2/3
        break;
      default:
        break;
    }
    this[__.speed] = speed    //speed
    this.visible = true
  }



  // 每一帧更新黑子的位置
  update() {
    this.x += this[__.speed]
    if (this.y > window.innerWidth + this.width) {
      databus.removeEnemey(this)
    }
  }

}