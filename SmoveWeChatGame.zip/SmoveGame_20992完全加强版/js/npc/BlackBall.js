import Animation from '../base/animation'
import DataBus from '../databus'

const BLACKBALL_IMG_SRC = 'images/HeiZi.png'
const screenWidth = window.innerWidth
const screenHeight = window.innerHeight

var scale = 3
var width = screenWidth - (screenWidth / scale) * 2;
var height = screenWidth - (screenWidth / scale) * 2;

const BLACKBALL_WIDTH = width/3 -2
const BLACKBALL_HEIGHT = width/3 -2

var enemy_x;
const __ = {
  speed: Symbol('speed')
}
let databus = new DataBus()
function rnd(start, end) {
  return Math.floor(Math.random() * (end - start) + start)
}

export default class BlackBall extends Animation {
  constructor() {
    super(BLACKBALL_IMG_SRC, BLACKBALL_WIDTH, BLACKBALL_HEIGHT)
  }


  init(speed) {
    enemy_x = Math.floor(Math.random() * 10)
    if (enemy_x <= 3) {
      enemy_x = 1;
    }
    else if (enemy_x > 3 && enemy_x <= 6) {
      enemy_x = 2;
    }
    else if (enemy_x > 6 && enemy_x <= 9) {
      enemy_x = 3;
    }
    switch (enemy_x) {
      case 1: this.x = screenWidth/scale
        this.y = 0
        break;
      case 2: this.x = screenWidth/scale + width/3
        this.y = 0
        break;
      case 3: this.x = screenWidth/scale + width*2/3
        this.y = 0   
        break;
      default:
        break;
    }
    this[__.speed] = speed    //speed
    this.visible = true
  }


  // 每一帧更新黑子的位置
  update() {
      this.y += this[__.speed]
      // 对象回收
      if (this.y > window.innerHeight + this.height - 260) {
        databus.removeBlackBall(this)
      }
  }
}